package a6im8.cecyt9.applogin;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

/**
 * Created by Usuario on 16/03/2017.
 */

public class otraActividad extends AppCompatActivity {
    TextView lblNombre, lblContra;
    String nombreUsr, contra;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.otraactividad);
        lblNombre = (TextView) findViewById(R.id.vistaDatos);
        lblContra = (TextView) findViewById(R.id.vistaDatos2);
        Intent intento2 = getIntent();

        String nombreUsr = intento2.getExtras().getString("Nombre").toString();
        String contra = intento2.getExtras().getString("Contra").toString();

        lblNombre.setText(lblNombre.getText().toString()+nombreUsr);
        lblContra.setText(lblContra.getText().toString()+contra);
    }
}
