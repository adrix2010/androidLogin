package a6im8.cecyt9.applogin;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
       EditText txtNombre,txtContra;
       Button Boton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtNombre = (EditText)findViewById(R.id.Nombre);
        txtContra = (EditText) findViewById(R.id.Contra);
        Boton = (Button) findViewById(R.id.Boton);

    public void entrar(View v) {
        if (txtNombre.getText().toString().equals("Adrian") && txtContra.getText().toString().equals("200")){
            Intent miIntento = new Intent(this, otraActividad.class);
            miIntento.putExtra("Nombre",txtNombre.getText().toString());
            miIntento.putExtra("Contra",txtContra.getText().toString());
            startActivity(miIntento);
        }
    }


    }

